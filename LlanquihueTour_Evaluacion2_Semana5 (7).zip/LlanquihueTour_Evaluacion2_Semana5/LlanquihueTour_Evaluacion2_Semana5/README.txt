PROYECTO: LlanquihueTour - Semana 5

Actividad: Organización modular y creación de una librería personalizada.

Este proyecto continúa la Evaluación 1 de Llanquihue Tour, manteniendo las clases Persona, Direccion y GuiaTuristico, y agregando organización modular, lectura de archivo, ArrayList, búsquedas, filtros y validaciones.

Estructura:
- app: clase Main con menú por consola.
- model: clases Persona, Direccion y GuiaTuristico.
- data: clase GestorDatos, encargada de leer el archivo guias.txt.
- service: clase GuiaService, encargada de mostrar, buscar y filtrar registros.
- util: clase Validador, encargada de validar datos básicos.
- resources: archivo guias.txt con los datos externos.

Requisitos cumplidos:
- Organización en paquetes.
- Atributos private.
- Constructores.
- Getters y setters.
- Método toString().
- Relación entre clases: GuiaTuristico hereda de Persona y Persona contiene Direccion.
- Uso de ArrayList.
- Lectura de archivo externo .txt.
- Validaciones básicas con try-catch.
- Búsqueda por nombre.
- Búsqueda por RUT.
- Filtro por especialidad.
- Visualización por consola.

Cómo ejecutar:
1. Abrir IntelliJ IDEA o NetBeans.
2. Crear o abrir el proyecto LlanquihueTour.
3. Copiar los paquetes dentro de src.
4. Confirmar que el archivo guias.txt esté en src/resources.
5. Ejecutar la clase app.Main.
