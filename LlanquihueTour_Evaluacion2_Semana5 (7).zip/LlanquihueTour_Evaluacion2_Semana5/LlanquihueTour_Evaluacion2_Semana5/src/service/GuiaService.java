package service;

import model.GuiaTuristico;

import java.util.ArrayList;

public class GuiaService {
    private ArrayList<GuiaTuristico> guias;

    public GuiaService(ArrayList<GuiaTuristico> guias) {
        this.guias = guias;
    }

    public void mostrarGuias() {
        if (guias.isEmpty()) {
            System.out.println("No hay guías turísticos cargados.");
        } else {
            for (GuiaTuristico guia : guias) {
                System.out.println("-----------------------------");
                System.out.println(guia);
            }
        }
    }

    public GuiaTuristico buscarPorNombre(String nombre) {
        for (GuiaTuristico guia : guias) {
            if (guia.getNombre().equalsIgnoreCase(nombre)) {
                return guia;
            }
        }
        return null;
    }

    public GuiaTuristico buscarPorRut(String rut) {
        for (GuiaTuristico guia : guias) {
            if (guia.getRut().equalsIgnoreCase(rut)) {
                return guia;
            }
        }
        return null;
    }

    public void filtrarPorEspecialidad(String especialidad) {
        boolean encontrado = false;

        for (GuiaTuristico guia : guias) {
            if (guia.getEspecialidad().equalsIgnoreCase(especialidad)) {
                System.out.println("-----------------------------");
                System.out.println(guia);
                encontrado = true;
            }
        }

        if (!encontrado) {
            System.out.println("No se encontraron guías con esa especialidad.");
        }
    }
}
