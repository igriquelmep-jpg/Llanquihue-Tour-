package data;

import model.Direccion;
import model.GuiaTuristico;
import util.Validador;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import model.RutaGastronomica;
import model.PaseoLacustre;
import model.ExcursionCultural;

public class GestorDatos {

    public ArrayList<GuiaTuristico> cargarGuias(String rutaArchivo) {
        ArrayList<GuiaTuristico> guias = new ArrayList<>();

        try {
            BufferedReader br = new BufferedReader(new FileReader(rutaArchivo));
            String linea;

            while ((linea = br.readLine()) != null) {
                try {
                    String[] datos = linea.split(";");

                    if (datos.length == 7) {
                        String rut = datos[0];
                        String nombre = datos[1];
                        String telefono = datos[2];
                        String calle = datos[3];
                        String ciudad = datos[4];
                        String region = datos[5];
                        String especialidad = datos[6];

                        if (Validador.rutValido(rut)
                                && Validador.textoValido(nombre)
                                && Validador.telefonoValido(telefono)
                                && Validador.textoValido(calle)
                                && Validador.textoValido(ciudad)
                                && Validador.textoValido(region)
                                && Validador.textoValido(especialidad)) {

                            Direccion direccion = new Direccion(calle, ciudad, region);

                            GuiaTuristico guia = new GuiaTuristico(
                                    rut,
                                    nombre,
                                    telefono,
                                    direccion,
                                    especialidad
                            );

                            guias.add(guia);
                        }
                    } else {
                        System.out.println("Línea ignorada por formato incorrecto.");
                    }

                } catch (Exception e) {
                    System.out.println("Error al procesar una línea: " + e.getMessage());
                }
            }

            br.close();
            System.out.println("Datos cargados correctamente desde el archivo.");

        } catch (Exception e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }

        return guias;
    }
    public void mostrarServiciosTuristicos() {

        System.out.println("SERVICIOS TURÍSTICOS DE LLANQUIHUE TOUR");
        System.out.println("---------------------------------------");

        System.out.println(new RutaGastronomica("Sabores del Sur", 4, 5));
        System.out.println(new RutaGastronomica("Ruta del Kuchen", 3, 4));

        System.out.println(new PaseoLacustre("Paseo por el Lago Llanquihue", 2, "Lancha turística"));
        System.out.println(new PaseoLacustre("Navegación al atardecer", 3, "Catamarán"));

        System.out.println(new ExcursionCultural("Historia de Puerto Varas", 2, "Iglesia Sagrado Corazón"));
        System.out.println(new ExcursionCultural("Patrimonio Alemán", 4, "Casa Kuschel"));
    }
}
