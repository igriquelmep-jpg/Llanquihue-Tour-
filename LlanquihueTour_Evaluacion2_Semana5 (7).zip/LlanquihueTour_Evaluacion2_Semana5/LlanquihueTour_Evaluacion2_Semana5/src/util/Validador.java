package util;

public class Validador {

    public static boolean textoValido(String texto) {
        return texto != null && !texto.trim().isEmpty();
    }

    public static boolean telefonoValido(String telefono) {
        return telefono != null && telefono.trim().length() >= 8;
    }

    public static boolean rutValido(String rut) {
        return rut != null && rut.trim().length() >= 9;
    }
}
