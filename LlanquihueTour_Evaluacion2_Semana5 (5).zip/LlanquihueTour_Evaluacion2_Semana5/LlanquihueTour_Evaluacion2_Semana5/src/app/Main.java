package app;

import data.GestorDatos;
import model.GuiaTuristico;
import service.GuiaService;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        GestorDatos gestor = new GestorDatos();

        ArrayList<GuiaTuristico> guias =
                gestor.cargarGuias("LlanquihueTour_Evaluacion2_Semana5/src/resources/guias.txt");

        GuiaService servicio = new GuiaService(guias);

        int opcion = 0;

        do {
            System.out.println("\n===== LLANQUIHUE TOUR =====");
            System.out.println("1. Mostrar todos los guías turísticos");
            System.out.println("2. Buscar guía por nombre");
            System.out.println("3. Buscar guía por RUT");
            System.out.println("4. Filtrar guías por especialidad");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opción: ");

            try {
                opcion = Integer.parseInt(teclado.nextLine());

                switch (opcion) {
                    case 1:
                        System.out.println("\n=== LISTA DE GUÍAS TURÍSTICOS ===");
                        servicio.mostrarGuias();
                        break;

                    case 2:
                        System.out.print("Ingrese el nombre del guía: ");
                        String nombre = teclado.nextLine();

                        GuiaTuristico guiaNombre = servicio.buscarPorNombre(nombre);

                        if (guiaNombre != null) {
                            System.out.println("\nGuía encontrado:");
                            System.out.println(guiaNombre);
                        } else {
                            System.out.println("No se encontró un guía con ese nombre.");
                        }
                        break;

                    case 3:
                        System.out.print("Ingrese el RUT del guía: ");
                        String rut = teclado.nextLine();

                        GuiaTuristico guiaRut = servicio.buscarPorRut(rut);

                        if (guiaRut != null) {
                            System.out.println("\nGuía encontrado:");
                            System.out.println(guiaRut);
                        } else {
                            System.out.println("No se encontró un guía con ese RUT.");
                        }
                        break;

                    case 4:
                        System.out.print("Ingrese la especialidad: ");
                        String especialidad = teclado.nextLine();

                        System.out.println("\n=== GUÍAS POR ESPECIALIDAD ===");
                        servicio.filtrarPorEspecialidad(especialidad);
                        break;

                    case 5:
                        System.out.println("Saliendo del sistema Llanquihue Tour...");
                        break;

                    default:
                        System.out.println("Opción no válida.");
                        break;
                }

            } catch (NumberFormatException e) {
                System.out.println("Debe ingresar un número válido.");
            }

        } while (opcion != 5);

        teclado.close();
    }
}
